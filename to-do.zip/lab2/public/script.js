const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');

async function fetchTasks() {
    const response = await fetch('/tasks');
    const tasks = await response.json();
    taskList.innerHTML = '';
    tasks.forEach(task => {
        const li = document.createElement('li');

        const taskInfo = document.createElement('div');
        taskInfo.classList.add('task-info');

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = task.completed;
        checkbox.addEventListener('change', () => toggleTaskCompletion(task._id, checkbox.checked));

        const taskTitle = document.createElement('span');
        taskTitle.textContent = task.title;

        taskInfo.appendChild(checkbox);
        taskInfo.appendChild(taskTitle);

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.classList.add('delete-btn');
        deleteBtn.addEventListener('click', () => deleteTask(task._id));

        li.appendChild(taskInfo);
        li.appendChild(deleteBtn);

        taskList.appendChild(li);
    });
}

addTaskBtn.addEventListener('click', async () => {
    const taskTitle = taskInput.value;
    if (taskTitle) {
        await fetch('/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title: taskTitle }),
        });
        taskInput.value = '';
        fetchTasks();
    }
});

async function toggleTaskCompletion(id, completed) {
    await fetch(`/tasks/${id}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ completed }),
    });
    fetchTasks();
}

async function deleteTask(id) {
    await fetch(`/tasks/${id}`, {
        method: 'DELETE',
    });
    fetchTasks();
}

fetchTasks();

